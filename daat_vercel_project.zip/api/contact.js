
import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

const TO_EMAIL = process.env.CONTACT_TO_EMAIL || 'your-email@example.com';
const FROM_EMAIL = process.env.CONTACT_FROM_EMAIL || 'Daat Podcast <no-reply@yourdomain.com>';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { name, email, message } = req.body || {};

    if (!name || !email || !message) {
      return res.status(400).json({ error: 'Missing fields' });
    }

    const textContent = `
New contact form message from Daat:

Name: ${name}
Email: ${email}

Message:
${message}
    `.trim();

    const htmlContent = `
      <div style="font-family: system-ui; line-height: 1.6; color: #111;">
        <h2>New contact message</h2>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Message:</strong></p>
        <div style="white-space: pre-wrap; border-radius: 8px; background:#f4f4f5; padding: 12px; border:1px solid #e4e4e7;">
          ${message.replace(/</g, '&lt;').replace(/>/g, '&gt;')}
        </div>
      </div>
    `;

    await resend.emails.send({
      from: FROM_EMAIL,
      to: TO_EMAIL,
      replyTo: email,
      subject: 'New contact message from Daat website',
      text: textContent,
      html: htmlContent
    });

    return res.status(200).json({ ok: true });
  } catch (error) {
    console.error('Contact API error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
}
